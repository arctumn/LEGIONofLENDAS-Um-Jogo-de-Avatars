package com.example.myapplication;


import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;


public class MenuPrincipal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_principal);

        //final TextView texto = findViewById(R.id.personagem);
        final ImageView avatar = findViewById(R.id.imgAvatar);

        Intent intent = getIntent();

        String bunda = intent.getStringExtra("moeda");

        //texto.setText(bunda);
        String ava = "R.drawable.ava"+bunda;
        int id = getResources().getIdentifier(bunda, "drawable", getPackageName());
        avatar.setImageResource(id);
    }
}