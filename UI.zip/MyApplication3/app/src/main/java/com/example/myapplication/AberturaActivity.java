package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class AberturaActivity extends AppCompatActivity {

    private TextView appName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abertura);

        //appName = findViewById(R.id.appName);

        //Typeface typeface = ResourcesCompat

        // Animation anim = AnimationUtils.loadAnimation();

        new Thread(() -> {
            try {
                //5 segundos talvez seja um pouco demais
                Thread.sleep(5000);
            }
            catch(InterruptedException e){
                e.printStackTrace();
            }

            Intent intent = new Intent(AberturaActivity.this, Login.class);
            startActivity(intent);
        }).start();


    }
}