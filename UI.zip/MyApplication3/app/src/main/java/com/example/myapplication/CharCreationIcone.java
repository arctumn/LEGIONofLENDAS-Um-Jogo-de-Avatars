package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import com.gigamole.infinitecycleviewpager.HorizontalInfiniteCycleViewPager;

import java.util.ArrayList;
import java.util.List;

public class CharCreationIcone extends AppCompatActivity {

    List<Integer> listImages = new ArrayList<>();


    /**
     * Da forma com isto está isto deveria seria a escolha de personagem para quem cria conta, não faz muito sentido ser a segunda
     * A UI tem alguns problemas para dispositivos menores, por exemplo não consegue se clicar no escolher caso o ecra seja menor que 5 polegadas
     * Eu fiz um layout optimizado para ecrãs menores que não fica muito pequeno para ecrãs grandes
     */
     @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initData();
        HorizontalInfiniteCycleViewPager pager = (HorizontalInfiniteCycleViewPager)findViewById(R.id.horizontal_cycle);
        MyAdapter adapter = new MyAdapter(listImages, getBaseContext());
        pager.setAdapter(adapter);

        final Button button = findViewById(R.id.btnEscolheAva);
        button.setOnClickListener(v -> {

            Toast.makeText(getApplicationContext(),"Clicked image ", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(CharCreationIcone.this, MenuPrincipal.class);
            intent.putExtra("moeda", "ava"+ pager.getRealItem());
            startActivity(intent);
        });

    }

    private void initData() {
        listImages.add(R.drawable.ava0);
        listImages.add(R.drawable.ava1);
        listImages.add(R.drawable.ava2);
        listImages.add(R.drawable.ava3);
        listImages.add(R.drawable.ava4);
        listImages.add(R.drawable.ava5);
        listImages.add(R.drawable.ava6);
        listImages.add(R.drawable.ava7);
        listImages.add(R.drawable.ava8);
        listImages.add(R.drawable.ava9);
    }
}